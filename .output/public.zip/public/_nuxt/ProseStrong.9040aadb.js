import{I as o,o as r,J as t,H as n}from"./entry.a434f63a.js";const s={};function c(e,a){return r(),t("strong",null,[n(e.$slots,"default")])}const f=o(s,[["render",c]]);export{f as default};
