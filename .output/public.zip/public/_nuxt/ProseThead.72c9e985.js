import{I as o,o as r,J as t,H as s}from"./entry.a434f63a.js";const a={};function n(e,c){return r(),t("thead",null,[s(e.$slots,"default")])}const d=o(a,[["render",n]]);export{d as default};
