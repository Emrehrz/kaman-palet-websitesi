import{I as e,o as r,J as c}from"./entry.a434f63a.js";const o={};function t(n,s){return r(),c("hr")}const _=e(o,[["render",t]]);export{_ as default};
