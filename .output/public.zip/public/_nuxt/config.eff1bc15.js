import{X as n,p as o,Y as i}from"./entry.a434f63a.js";const f={},t=n(f);function s(){const p=o();return p._appConfig||(p._appConfig=i(t)),p._appConfig}export{s as u};
