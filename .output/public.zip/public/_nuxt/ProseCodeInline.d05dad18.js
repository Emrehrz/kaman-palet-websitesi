import{I as o,o as n,J as r,H as s}from"./entry.a434f63a.js";const t={};function c(e,a){return n(),r("code",null,[s(e.$slots,"default")])}const d=o(t,[["render",c]]);export{d as default};
