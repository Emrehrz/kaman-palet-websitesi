import{I as o,o as r,J as s,H as t}from"./entry.a434f63a.js";const n={};function c(e,a){return r(),s("p",null,[t(e.$slots,"default")])}const f=o(n,[["render",c]]);export{f as default};
