import{I as r,o,J as t,H as s}from"./entry.a434f63a.js";const n={};function c(e,a){return o(),t("tr",null,[s(e.$slots,"default")])}const f=r(n,[["render",c]]);export{f as default};
