import{h as n,k as e}from"./entry.a434f63a.js";const t=n({name:"DocumentDrivenNotFound",render(){return e("div","Document not found")}});export{t as default};
