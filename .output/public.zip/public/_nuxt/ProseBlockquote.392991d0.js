import{I as o,o as t,J as r,H as c}from"./entry.a434f63a.js";const s={};function n(e,l){return t(),r("blockquote",null,[c(e.$slots,"default")])}const f=o(s,[["render",n]]);export{f as default};
