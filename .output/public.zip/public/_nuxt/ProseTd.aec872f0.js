import{I as o,o as r,J as t,H as s}from"./entry.a434f63a.js";const n={};function c(e,a){return r(),t("td",null,[s(e.$slots,"default")])}const d=o(n,[["render",c]]);export{d as default};
