import{I as o,o as r,J as t,H as s}from"./entry.a434f63a.js";const a={};function n(e,c){return r(),t("table",null,[s(e.$slots,"default")])}const f=o(a,[["render",n]]);export{f as default};
