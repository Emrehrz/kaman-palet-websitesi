import{I as o,o as r,J as t,H as s}from"./entry.a434f63a.js";const n={};function c(e,a){return r(),t("th",null,[s(e.$slots,"default")])}const f=o(n,[["render",c]]);export{f as default};
